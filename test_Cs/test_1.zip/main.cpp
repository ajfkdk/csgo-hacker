#include "csgo_cheats.hpp"


int main(int argc, char* argv[])
{
	start_cheats_csgo();
	return 0;
}


